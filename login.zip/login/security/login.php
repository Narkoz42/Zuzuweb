<?php
session_start();
date_default_timezone_set('Europe/Istanbul');

// Doğrudan erişimi engellemek için kontrol
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    http_response_code(404);
    echo "404 - Not Found";
    exit();
}

// Giriş yapma işlemleri
$username = $_POST["username"];
$password = $_POST["password"];

// Anti SQL Injection: Giriş bilgilerini temizle
$username = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
$password = htmlspecialchars($password, ENT_QUOTES, 'UTF-8');

// Kontrolleri yap
if (strlen($username) < 3 || preg_match('/[^A-Za-z]/', $username) || preg_match('/[\s\'^£$%&*()}{@#~?><>,|=+¬-]/', $username)) {
    $_SESSION["error"] = "Username should be at least 3 letters long and should only contain letters (A-Z, a-z).";
    header("Location: /login");
    exit();
}

if (strlen($password) < 15 || preg_match('/\s/', $password) || preg_match('/[^A-Za-z0-9]/', $password)) {
    $_SESSION["error"] = "Password should be at least 15 letters long and should only contain letters (A-Z, a-z).";
    header("Location: /login");
    exit();
}

// PDO ile veritabanına bağlanın ve kullanıcıyı kontrol edin
try {
    $conn = new PDO("mysql:host=localhost;dbname=panel", "root", "");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Deneme sayısını ve zaman aşımı süresini kontrol etmek için oturum değişkenlerini tanımlayın
    if (!isset($_SESSION["login_attempts"])) {
        $_SESSION["login_attempts"] = 0;
    }

    if (!isset($_SESSION["last_login_attempt_time"])) {
        $_SESSION["last_login_attempt_time"] = time();
    }

    // Giriş denemesi başarısız olduğunda, deneme sayısını artırın ve zaman aşımını kontrol edin
    $attempts = $_SESSION["login_attempts"];
    $attempts++;
    $_SESSION["login_attempts"] = $attempts;

    if ($attempts % 3 === 0) {
        $current_time = time();
        $last_attempt_time = $_SESSION["last_login_attempt_time"];

        if ($current_time - $last_attempt_time < 180) {
            $_SESSION["error"] = "Too many unsuccessful login attempts. Please wait for 180 seconds.";
            header("Location: /login");
            exit();
        }

        // Zaman aşımı süresini güncelle
        $_SESSION["last_login_attempt_time"] = $current_time;
    }

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row && password_verify($password, $row["password"])) {
        // Kullanıcının son kullanma tarihini kontrol edin
        $current_time = time();
        $expiration_date = strtotime($row["bitis_tarih"]);

        if ($expiration_date && $current_time > $expiration_date) {
            $_SESSION["error"] = "Your account has expired. Please contact the administrator.";
            header("Location: /login");
            exit();
        }
        // Başarılı giriş, deneme sayısını ve zaman aşımını sıfırla
        $_SESSION["login_attempts"] = 0;
        $_SESSION["last_login_attempt_time"] = time();

        $_SESSION["username"] = $username;
        $_SESSION["role"] = $row["role"];
        if ($row["role"] === "admin") {
            header("Location: /login/admin");
            exit();
        } else {
            header("Location: /login/dashboard");
            exit();
        }
    } else {
        $_SESSION["error"] = "Username Or Password Wrong!"; // Set the error message
        header("Location: /login");
        exit();
    }
} catch (PDOException $e) {
    die("Veritabanına bağlanılamadı: " . $e->getMessage());
}
?>
