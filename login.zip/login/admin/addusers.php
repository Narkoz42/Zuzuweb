<?php
session_start();
date_default_timezone_set('Europe/Istanbul');

// Eğer oturum açılmamışsa veya kullanıcı admin değilse yönlendir
if (!isset($_SESSION["username"]) || $_SESSION["role"] !== "admin") {
    header("Location: ./");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    http_response_code(404);
    echo "404 - Not Found";
    exit();
}

// Set the inactivity time of 15 minutes (900 seconds)
$inactivity_time = 15 * 60;

if (isset($_SESSION['last_timestamp']) && (time() - $_SESSION['last_timestamp']) > $inactivity_time) {
    session_unset();
    session_destroy();

    // Redirect user to login page
    header("Location: ./");
    exit();
} else {
    // Regenerate new session id and delete the old one to prevent session fixation attack
    session_regenerate_id(true);

    // Update the last timestamp
    $_SESSION['last_timestamp'] = time();
}

// Kullanıcı ekleme işlemi
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $role = $_POST["role"];
    $days = $_POST["days"];

    // Veritabanına bağlanın ve kullanıcıyı ekleyin
    try {
        $conn = new PDO("mysql:host=localhost;dbname=panel", "root", "");
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Kullanıcı adının benzersiz olup olmadığını kontrol et
        $checkQuery = "SELECT username FROM users WHERE username = :username";
        $checkStmt = $conn->prepare($checkQuery);
        $checkStmt->bindParam(":username", $username);
        $checkStmt->execute();

        if ($checkStmt->rowCount() > 0) {
            echo "Bu kullanıcı adı zaten sistemde kayıtlı.";
            exit();
        }

        $password = generatePassword(); // Rastgele şifre oluştur
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT); // Şifreyi hashle

        $creator = $_SESSION["username"]; // Oluşturan kullanıcı adını al

        // Şu anki tarihi al
        $current_time = time();

        // POST ile gönderilen gün sayısını ekleyerek bitiş tarihini hesapla
        $expiration_date = date('Y-m-d H:i:s', strtotime("+$days days", $current_time));

        $insertQuery = "INSERT INTO users (username, password, role, creator, eklenen_tarih, bitis_tarih) VALUES (:username, :password, :role, :creator, :eklenen_tarih, :bitis_tarih)";
        $insertStmt = $conn->prepare($insertQuery);
        $insertStmt->bindParam(":username", $username);
        $insertStmt->bindParam(":password", $hashedPassword);
        $insertStmt->bindParam(":role", $role);
        $insertStmt->bindParam(":creator", $creator);
        $insertStmt->bindParam(":eklenen_tarih", date('Y-m-d H:i:s', $current_time));
        $insertStmt->bindParam(":bitis_tarih", $expiration_date);

        if ($insertStmt->execute()) {
            echo "Kullanıcı başarıyla oluşturuldu.<br>";
            echo "Kullanıcı Adı: $username<br>";
            echo "Şifre: $password<br>";
            echo "Gün: $expiration_date<br>";
            echo "Rol: $role";
        } else {
            echo "Kullanıcı oluşturulurken hata oluştu.";
        }
        $conn = null; // Bağlantıyı kapat
    } catch (PDOException $e) {
        die("Veritabanına bağlanılamadı: " . $e->getMessage());
    }
}

// Rastgele şifre oluşturma fonksiyonu
function generatePassword($length = 50) {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $index = mt_rand(0, strlen($characters) - 1);
        $password .= $characters[$index];
    }
    return $password;
}
?>
