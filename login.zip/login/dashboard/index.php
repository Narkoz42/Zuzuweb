<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Açılır Kapanır Hamburger Menü</title>
    <style>
        body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    position: relative;
  }
        
        .navbar {
            background-color: #333;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            box-shadow: 0 1px 5px rgba(255, 255, 0, 255);
        }

        .icon {
            font-size: 30px;
            color: white;
            cursor: pointer;
            transition: transform 0.3s;
        }

        .icon:hover {
            transform: scale(1.1);
        }

        .menu {
            position: fixed;
            top: 0;
            left: -250px;
            width: 250px;
            height: 100%;
            background-color: #222;
            padding-top: 60px;
            transition: left 0.3s;
        }

        .menu a {
            display: block;
            padding: 15px 20px;
            color: white;
            text-decoration: none;
            font-size: 18px;
            transition: background-color 0.3s;
        }

        .menu a:hover {
            background-color: #555;
        }

        .submenu {
        padding-left: 20px;
        display: none; /* Başlangıçta alt menüyü gizle */
        }

        .show-menu {
            left: 0;
        }

        .show-submenu {
            display: block;
        }

        .submenu a {
        font-size: 14px;
        }
        
        a:hover {
            position: relative;
        }

        a:hover::after {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, rgba(255, 255, 255, 0.2), rgba(255, 255, 255, 0.5), rgba(255, 255, 255, 0.2));
            animation: parilti 1.5s infinite;
        }
        
.tkullanici {
width: 350px; /* Dikdörtgenin genişliği */
    height: 80px; /* Dikdörtgenin yüksekliği */
    border: 2px solid black;
    border-radius: 10px;
    position: absolute;
    margin-top: 120px;
    left: 50%;
    transform: translate(-50%, -50%);
    transition: transform 0.3s ease-in-out;
    display: flex;
    align-items: center;
}

img {
    width: 50px;
    height: auto;
    margin-top: -10px;
    margin-left: 290px;
    transition: transform 0.3s ease;
}
p {
    margin-top: -20px;
    margin-left: -330px;
}

.ksayi {
    margin-top: 24px;
    margin-left: 10px;
}

.uyelikturu {
width: 350px; /* Dikdörtgenin genişliği */
    height: 80px; /* Dikdörtgenin yüksekliği */
    border: 2px solid black;
    border-radius: 10px;
    position: absolute;
    margin-top: 220px;
    left: 50%;
    transform: translate(-50%, -50%);
    transition: transform 0.3s ease-in-out;
    display: flex;
    align-items: center;
}

img {
    width: 50px;
    height: auto;
    margin-top: -10px;
    margin-left: 290px;
    transition: transform 0.3s ease;
}
p {
    margin-top: -20px;
    margin-left: -330px;
}

.utur {
    margin-top: 24px;
    margin-left: 10px;
}

        @keyframes parilti {
            0% {
                transform: scale(1);
                opacity: 1;
            }
            100% {
                transform: scale(1.5);
                opacity: 0;
            }
        }
    </style>
</head>
<body>
    <div class="navbar">
        <div class="icon" onclick="toggleMenu()">
            &#9776;
        </div>
        <div class="menu" id="menu">
            <a href="#home">Ana Sayfa</a>
            <a href="#about" onclick="toggleSubmenu()">Hakkında</a>
            <div class="submenu" id="submenu">
                <a href="#subitem1">Alt Menü Öğesi 1</a>
                <a href="#subitem2">Alt Menü Öğesi 2</a>
                <a href="#subitem3">Alt Menü Öğesi 3</a>
            </div>
            <a href="#services">Hizmetler</a>
            <a href="#contact">İletişim</a>
        </div>
    </div>
<div class="tkullanici">
        <img src="foto.jpg" alt="Bir Fotoğraf">
        <p>Toplam Kullanıcı</p>
    </div>
    <div class="tkullanici">
        <p class="ksayi">90</p>
    </div>

<div class="uyelikturu">
        <img src="foto.jpg" alt="Bir Fotoğraf">
        <p>Üyelik Türü</p>
    </div>
    <div class="uyelikturu">
        <p class="utur">Admin</p>
    </div>

    <script>
        function toggleMenu() {
            var menu = document.getElementById("menu");
            menu.classList.toggle("show-menu");
        }

        function toggleSubmenu() {
            var submenu = document.getElementById("submenu");
            submenu.classList.toggle("show-submenu");
        }

        window.addEventListener('click', function(event) {
            var menu = document.getElementById("menu");
            var icon = document.querySelector(".icon");
            var submenu = document.getElementById("submenu");

            if (!menu.contains(event.target) && !icon.contains(event.target) && !submenu.contains(event.target)) {
                menu.classList.remove("show-menu");
                submenu.classList.remove("show-submenu");
            }
        });
    </script>
</body>
</html>